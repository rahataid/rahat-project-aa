export interface GetTriggers {
    page: number;
    perPage: number;
    phaseId: string;
}

export interface GetOneTrigger {
    repeatKey: string;
}

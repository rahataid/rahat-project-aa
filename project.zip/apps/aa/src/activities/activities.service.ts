import { ConfigService } from '@nestjs/config';
import { Injectable, Logger } from '@nestjs/common';
import { CommunicationService } from '@rumsan/communication/services/communication.client';

import { PaginatorTypes, PrismaService, paginator } from '@rumsan/prisma';
import {
  ActivityCommunicationData,
  ActivityDocs,
  AddActivityData,
  GetActivitiesDto,
  GetOneActivity,
  RemoveActivityData,
  UpdateActivityData,
} from './dto';
import { StakeholdersService } from '../stakeholders/stakeholders.service';
import { BeneficiaryService } from '../beneficiary/beneficiary.service';
import { ActivitiesStatus } from '@prisma/client';
import { RpcException } from '@nestjs/microservices';
import { UUID } from 'crypto';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { EVENTS } from '../constants';

const paginate: PaginatorTypes.PaginateFunction = paginator({ perPage: 20 });

@Injectable()
export class ActivitiesService {
  private readonly logger = new Logger(ActivitiesService.name);
  private communicationService: CommunicationService;

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
    private readonly stakeholdersService: StakeholdersService,
    private readonly beneficiaryService: BeneficiaryService,
    private eventEmitter: EventEmitter2
  ) {
    this.communicationService = new CommunicationService({
      baseURL: this.configService.get('COMMUNICATION_URL'),
      headers: {
        appId: this.configService.get('COMMUNICATION_APP_ID'),
      },
    });
  }

  async add(payload: AddActivityData) {
    try {
      const {
        activityCommunication,
        title,
        isAutomated,
        leadTime,
        categoryId,
        description,
        phaseId,
        responsibility,
        source,
        activityDocuments,
      } = payload;

      const createActivityCommunicationPayload = [];
      const createActivityPayoutPayload = [];
      const docs = activityDocuments || [];
      let campaignId: number;

      if (activityCommunication?.length) {
        for (const comms of activityCommunication) {
          switch (comms.groupType) {
            case 'STAKEHOLDERS':
              campaignId = await this.processStakeholdersCommunication(
                comms,
                title
              );
              createActivityCommunicationPayload.push({
                ...comms,
                campaignId,
              });
              break;
            case 'BENEFICIARY':
              campaignId = await this.processBeneficiaryCommunication(
                comms,
                title
              );
              createActivityCommunicationPayload.push({
                ...comms,
                campaignId,
              });
              break;
            default:
              break;
          }
        }
      }

      const newActivity = await this.prisma.activities.create({
        data: {
          title,
          description,
          leadTime,
          responsibility,
          source,
          isAutomated,
          category: {
            connect: { uuid: categoryId },
          },
          phase: {
            connect: { uuid: phaseId },
          },
          activityCommunication: createActivityCommunicationPayload,
          activityPayout: createActivityPayoutPayload,
          activityDocuments: JSON.parse(JSON.stringify(docs)),
        },
      });

      this.eventEmitter.emit(EVENTS.ACTIVITY_ADDED, {});
      return newActivity;
    } catch (err) {
      console.log(err);
    }
  }

  async processStakeholdersCommunication(
    payload: ActivityCommunicationData,
    title: string
  ) {
    const transportId = await this.getTransportId(payload.communicationType);

    const { data: audience } =
      await this.communicationService.communication.listAudience();

    const stakeholderGroup = await this.stakeholdersService.findOneGroup({
      uuid: payload.groupId,
    });

    const stakeholderEmails = stakeholderGroup.stakeholders.map(
      (stakeholder) => stakeholder.email
    );
    const stakeholderPhones = stakeholderGroup.stakeholders.map(
      (stakeholder) => stakeholder.phone
    );

    const audienceEmails = audience.map((audience) => audience.details.email);
    const audiencePhones = audience.map((audience) => audience.details.phone);

    // get stakeholders not in audience
    const stakeholdersNotInAudience = stakeholderGroup.stakeholders.filter(
      (stakeholder) => {
        return (
          !audienceEmails.includes(stakeholder.email) ||
          !audiencePhones.includes(stakeholder.phone)
        );
      }
    );

    // get audience which already has stakeholders
    const stakeholdersInAudience = audience.filter((audience) => {
      return (
        stakeholderEmails.includes(audience.details.email) ||
        stakeholderPhones.includes(audience.details.phone)
      );
    });

    const audienceIds = [
      ...stakeholdersInAudience.map((audience) => audience.id),
    ];

    for (const stakeholder of stakeholdersNotInAudience) {
      const response =
        await this.communicationService.communication.createAudience({
          details: {
            name: stakeholder?.name,
            phone: stakeholder?.phone,
            // fix: add email to audience type in sdk
            // @ts-ignore: Unreachable code error
            email: stakeholder?.email,
          },
        });
      audienceIds.push(response.data.id);
    }

    const campaignPayload = {
      audienceIds: audienceIds,
      name: title,
      status: 'ONGOING',
      transportId: transportId,
      type: payload.communicationType.toUpperCase(),
      details: {
        message: '',
        ivrFileName: '',
        ivrMediaURL: '',
      },
      file: {},
      startTime: new Date(),
    };

    if (payload.message) {
      campaignPayload.details.message = payload.message;
    }

    if (payload.audioURL) {
      campaignPayload.file = payload.audioURL;
    }

    //create campaign
    const campaign =
      await this.communicationService.communication.createCampaign(
        campaignPayload
      );
    return campaign.data.id;
  }

  async processBeneficiaryCommunication(
    payload: ActivityCommunicationData,
    title: string
  ) {
    const transportId = await this.getTransportId(payload.communicationType);
    const { data: audience } =
      await this.communicationService.communication.listAudience();
    const beneficiaryGroup = await this.beneficiaryService.getOneGroup(
      payload.groupId as UUID
    );
    const groupedBeneficiaries = beneficiaryGroup.groupedBeneficiaries;

    const beneficiaryEmails = groupedBeneficiaries.map(
      (beneficiary) => beneficiary.Beneficiary.pii.email
    );
    const beneficiaryPhones = groupedBeneficiaries.map(
      (beneficiary) => beneficiary.Beneficiary.pii.phone
    );

    const audienceEmails = audience.map((audience) => audience.details.email);
    const audiencePhones = audience.map((audience) => audience.details.phone);

    // get beneficiaries not in audience
    const beneficiariesNotInAudience = groupedBeneficiaries.filter(
      (beneficiary) => {
        return (
          !audienceEmails.includes(beneficiary.Beneficiary.pii.email) ||
          !audiencePhones.includes(beneficiary.Beneficiary.pii.phone)
        );
      }
    );

    // get audience which already has beneficiaries
    const beneficiariesInAudience = audience.filter((audience) => {
      return (
        beneficiaryEmails.includes(audience.details.email) ||
        beneficiaryPhones.includes(audience.details.phone)
      );
    });

    const audienceIds = [
      ...beneficiariesInAudience.map((audience) => audience.id),
    ];

    for (const beneficiary of beneficiariesNotInAudience) {
      const response =
        await this.communicationService.communication.createAudience({
          details: {
            name: beneficiary?.Beneficiary?.pii?.name,
            phone: beneficiary?.Beneficiary?.pii?.phone,
            // fix: add email to audience type in sdk
            // @ts-ignore: Unreachable code error
            email: beneficiary?.Beneficiary?.pii?.email,
          },
        });
      audienceIds.push(response.data.id);
    }

    const campaignPayload = {
      audienceIds: audienceIds,
      name: title,
      status: 'ONGOING',
      transportId: transportId,
      type: payload.communicationType.toUpperCase(),
      details: {
        message: '',
        ivrFileName: '',
        ivrMediaURL: '',
      },
      file: {},
      startTime: new Date(),
    };

    if (payload.message) {
      campaignPayload.details.message = payload.message;
    }

    if (payload.audioURL) {
      campaignPayload.file = payload.audioURL;
    }

    //create campaign
    const campaign =
      await this.communicationService.communication.createCampaign(
        campaignPayload
      );
    return campaign.data.id;
  }

  async getTransportId(transportName: string) {
    const transports =
      await this.communicationService.communication.listTransport();
    const t = transports.data.find(
      (d) => d.name.toLowerCase() === transportName.toLowerCase()
    );
    return t.id;
  }

  async getOne(payload: GetOneActivity) {
    try {
      const { uuid } = payload;
      const { activityCommunication: aComm, ...activityData } =
        await this.prisma.activities.findUnique({
          where: {
            uuid: uuid,
          },
          include: {
            category: true,
            phase: true,
          },
        });

      const activityCommunication = [];
      const activityPayout = [];

      if (Array.isArray(aComm) && aComm.length) {
        for (const comm of aComm) {
          const communication = JSON.parse(
            JSON.stringify(comm)
          ) as ActivityCommunicationData & { campaignId: number };
          let campaignData = null;
          try {
            const { data } =
              await this.communicationService.communication.getCampaign(
                communication.campaignId
              );
            campaignData = data;
          } catch (err) {
            this.logger.error('Error fetching campagin details.');
          }
          let group: any;
          let groupName: string;

          switch (communication.groupType) {
            case 'STAKEHOLDERS':
              group = await this.prisma.stakeholdersGroups.findUnique({
                where: {
                  uuid: communication.groupId,
                },
              });
              groupName = group.name;
              break;
            case 'BENEFICIARY':
              group = await this.prisma.beneficiaryGroups.findUnique({
                where: {
                  uuid: communication.groupId,
                },
              });
              groupName = group.name;
              break;
            default:
              break;
          }

          activityCommunication.push({
            ...communication,
            groupName: groupName,
            campaignData: campaignData,
          });
        }
      }

      return {
        ...activityData,
        activityCommunication,
        activityPayout,
      };
    } catch (err) {
      console.log(err);
    }
  }

  async getAll(payload: GetActivitiesDto) {
    const { page, perPage, title, category, phase, isComplete, isApproved } =
      payload;

    const query = {
      where: {
        isDeleted: false,
        ...(title && { title: { contains: title, mode: 'insensitive' } }),
        ...(category && { categoryId: category }),
        ...(phase && { phaseId: phase }),
        ...(isComplete && { isComplete: isComplete }),
        ...(isApproved && { isApproved: isApproved }),
      },
      include: {
        category: true,
        phase: true,
      },
      orderBy: {
        createdAt: 'desc',
      },
    };

    return paginate(this.prisma.activities, query, {
      page,
      perPage,
    });
  }

  async remove(payload: RemoveActivityData) {
    const deletedActivity = await this.prisma.activities.update({
      where: {
        uuid: payload.uuid,
      },
      data: {
        isDeleted: true,
      },
    });

    this.eventEmitter.emit(EVENTS.ACTIVITY_DELETED, {});

    return deletedActivity;
  }

  async triggerCommunication(campaignId: string) {
    const cId = Number(campaignId);
    const triggerResponse =
      await this.communicationService.communication.triggerCampaign(cId);
    return triggerResponse.data;
  }

  async updateStatus(payload: {
    uuid: string;
    status: ActivitiesStatus;
    activityDocuments: Array<ActivityDocs>;
    user: any
  }) {
    const { status, uuid, activityDocuments, user } = payload;

    const docs = activityDocuments || [];

    if (status === 'COMPLETED') {
      this.eventEmitter.emit(EVENTS.ACTIVITY_COMPLETED, {});
    }

    const updatedActivity = await this.prisma.activities.update({
      where: {
        uuid: uuid,
      },
      data: {
        status: status,
        activityDocuments: JSON.parse(JSON.stringify(docs)),
        ...((status === 'COMPLETED') && {completedBy: user?.name})
      },
    });

    return updatedActivity;
  }

  async update(payload: UpdateActivityData) {
    const {
      uuid,
      activityCommunication,
      isAutomated,
      title,
      source,
      responsibility,
      phaseId,
      leadTime,
      description,
      categoryId,
      activityDocuments,
    } = payload;
    const activity = await this.prisma.activities.findUnique({
      where: {
        uuid: uuid,
      },
    });
    if (!activity) throw new RpcException('Activity not found.');

    const updateActivityCommunicationPayload = [];
    const updateActivityDocuments = activityDocuments?.length
      ? JSON.parse(JSON.stringify(activityDocuments))
      : [];

    if (activityCommunication?.length) {
      for (const comms of activityCommunication) {
        let campaignId: number;
        switch (comms.groupType) {
          case 'STAKEHOLDERS':
            if (comms.campaignId) {
              const campaginDetails =
                await this.communicationService.communication.getCampaign(
                  Number(comms.campaignId)
                );
              const audienceIds = campaginDetails.data?.audiences?.map(
                (d) => d.id
              );

              await this.communicationService.communication.updateCampaign(
                comms.campaignId,
                {
                  audienceIds: audienceIds,
                  details: JSON.parse(
                    JSON.stringify({ message: comms.message })
                  ),
                  name: title || activity.title,
                }
              );

              updateActivityCommunicationPayload.push(comms);
              break;
            }
            campaignId = await this.processStakeholdersCommunication(
              comms,
              title || activity.title
            );

            updateActivityCommunicationPayload.push({
              ...comms,
              campaignId,
            });
            break;
          case 'BENEFICIARY':
            if (comms.campaignId) {
              const campaginDetails =
                await this.communicationService.communication.getCampaign(
                  Number(comms.campaignId)
                );
              const audienceIds = campaginDetails.data?.audiences?.map(
                (d) => d.id
              );

              await this.communicationService.communication.updateCampaign(
                comms.campaignId,
                {
                  audienceIds: audienceIds,
                  details: JSON.parse(
                    JSON.stringify({ message: comms.message })
                  ),
                  name: title || activity.title,
                }
              );

              updateActivityCommunicationPayload.push(comms);
              break;
            }
            campaignId = await this.processBeneficiaryCommunication(
              comms,
              title || activity.title
            );

            updateActivityCommunicationPayload.push({
              ...comms,
              campaignId,
            });
            break;
          default:
            break;
        }
      }
    }

    return await this.prisma.activities.update({
      where: {
        uuid: uuid,
      },
      data: {
        title: title || activity.title,
        description: description || activity.description,
        source: source || activity.source,
        responsibility: responsibility || activity.responsibility,
        leadTime: leadTime || activity.leadTime,
        isAutomated: isAutomated,
        phase: {
          connect: {
            uuid: phaseId || activity.phaseId,
          },
        },
        category: {
          connect: {
            uuid: categoryId || activity.categoryId,
          },
        },
        activityCommunication: updateActivityCommunicationPayload,
        activityDocuments:
          updateActivityDocuments || activity.activityDocuments,
        updatedAt: new Date(),
      },
    });
  }

  async getCommunicationLogs() {
    const commsLogs =
      await this.communicationService.communication.getCommunicationLogs();
    return commsLogs.data;
  }
}

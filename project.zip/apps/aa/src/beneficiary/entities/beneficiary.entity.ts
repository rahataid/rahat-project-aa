export class Beneficiary {}

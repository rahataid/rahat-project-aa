export abstract class AbstractSource {
  public abstract criteriaCheck(payload: any): any;
}

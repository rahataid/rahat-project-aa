-- AlterTable
ALTER TABLE "tbl_activities" ADD COLUMN     "completedBy" TEXT;

-- AlterTable
ALTER TABLE "tbl_triggers" ADD COLUMN     "triggeredBy" TEXT;

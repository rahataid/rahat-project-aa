#! /bin/bash

source ./tools/scripts/utils.sh

rm_modules
drop_pg_database
